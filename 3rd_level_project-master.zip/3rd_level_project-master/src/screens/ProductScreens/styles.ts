import { StyleSheet } from "react-native";

const style = StyleSheet.create({

    root: {
        padding: 10,
        backgroundColor: '#ffffff',
    },
    title: {
        borderTopWidth: 1,
        borderBottomWidth: 1,
        padding: 10,
        fontSize: 18,
        fontWeight: 'bold',
        borderColor: '#d1d1d1',
    },
    desctitle: {
        fontWeight: 'bold',
        fontSize: 18,
    },
    price: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    priceQuantity:{
        flexDirection: 'row',
        marginTop:10,
        backgroundColor: '#fff',
        marginVertical: 5,
        alignItems: 'center',
        justifyContent: 'space-between',
        
    },
    oldPrice: {
        fontSize: 12,
        fontWeight: 'normal',
        marginLeft: 5,
        textDecorationLine: 'line-through',
    },
    description: {
        
        lineHeight: 20,
    },
    picker: {
        backgroundColor: '#d1d1d1',
        borderWidth: 1,
        width: '100%',
        marginTop: 15
    }
    
})

export default style;