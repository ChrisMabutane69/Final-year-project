import { View, Text, ScrollView } from 'react-native'
import {Picker} from '@react-native-picker/picker'
import React, {useState} from 'react'
import {useRoute} from '@react-navigation/native';
import style from './styles'
import product from '../../data/product'
import QuantitySelector from '../../components/QuantitySelector';
import Button from '../../components/Button'
import ImageSlider from '../../components/ImageSlider'



const ProductScreen = () => {
    const [selectedOption, setSelectedOption] = useState(product.options ? product.options[0] : null);
    const [quantity, setQuantity] = useState(1);

    const route = useRoute();
    console.log(route.params);

  return (
    <ScrollView style={style.root}>
      
        {/* ImageSlider */}
        <ImageSlider images={product.images}/>

        <Text style={style.title}>{product.title}</Text>

        {/* ==Option selector */}
        <Picker style={style.picker} selectedValue={selectedOption} onValueChange={(itemValue) =>setSelectedOption(itemValue)}>

            {product.options.map(option =>(<Picker.Item label={option} value={option} />))}
        </Picker>

        
        <View style={style.priceQuantity}>
          {/* Price */}
          <Text style={style.price}>
              from R{product.price}
              {product.oldPrice && <Text style={style.oldPrice}> R{product.oldPrice}</Text>}
          </Text>

          {/* Quantity selector */}
          <QuantitySelector quantity={quantity} setQuantity={setQuantity} />
        </View>
        
        <Text style={style.desctitle}>Features & details</Text>
        

        {/* Description */}
        <Text style={style.description}>
            {product.description}
        </Text>

        

      {/* Button */}
      <Button
        text={'Add To Cart'}
        onPress={() => {
          console.warn('Add to cart');
        }}
        containerStyles={{backgroundColor: '#e3c905'}}
      />
      <Button
        text={'Buy Now'}
        onPress={() => {
          console.warn('Buy now');
        }}
      />
    
    </ScrollView>
  )
}

export default ProductScreen